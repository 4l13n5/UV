from PyQt4 import QtGui, QtCore
import sys
import pyaudio
import wave
import os
import tkinter
import numpy as np
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt4agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import threading
import sounddevice as sd
from multiprocessing import Process, process
import math
from copy import deepcopy
from scipy.io.wavfile import write




class Main(QtGui.QMainWindow):
    kod=[]
    pastable=np.array([])
    export_name=""
    def __init__(self, parent = None):
        super(Main, self).__init__(parent)
        self.setMinimumSize(1000,500)
        self.silence =np.zeros(44100)
        self.stop_flag=0
        Main.kod = []
        self.pastable = np.array([])
        self.export_name=""

        #icons
        self.add = QtGui.QIcon("plus.png")
        self.play_btn = QtGui.QIcon("play-btn.png")
        self.stop_btn = QtGui.QIcon("stop-btn.png")
        self.save_btn = QtGui.QIcon("save.jpg")


        # main button
        self.addButton = QtGui.QPushButton()
        self.addButton.clicked.connect(self.addWidget)
        self.addButton.setIcon(self.add)
        self.addButton.setToolTip("New Track")


        self.playbutton = QtGui.QPushButton()
        self.playbutton.clicked.connect(self.play_all)
        self.playbutton.setIcon(self.play_btn)
        self.playbutton.setToolTip("Play")

        self.export = QtGui.QPushButton()
        self.export.clicked.connect(self.export_track)
        self.export.setIcon(self.save_btn)
        self.export.setToolTip("Export as")

        # scroll area widget contents - layout
        self.scrollLayout = QtGui.QFormLayout()

        # scroll area widget contents
        self.scrollWidget = QtGui.QWidget()
        self.scrollWidget.setLayout(self.scrollLayout)

        # scroll area
        self.scrollArea = QtGui.QScrollArea()
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setWidget(self.scrollWidget)

        # main layout
        self.mainLayout = QtGui.QGridLayout()

        # add all main to the main vLayout
        self.mainLayout.addWidget(self.addButton,0,0,1,1)
        self.mainLayout.addWidget(self.playbutton,0,1,1,1)
        self.mainLayout.addWidget(self.export,0,2,1,1)
        self.mainLayout.addWidget(self.scrollArea,1,0,1,3)

        # central widget
        self.centralWidget = QtGui.QWidget()
        self.centralWidget.setLayout(self.mainLayout)

        # set central widget
        self.setCentralWidget(self.centralWidget)

    def addWidget(self):
        temp = Test(len(Main.kod))
        self.kod.append(temp)
        self.scrollLayout.addRow(temp)

    def remove_widget(self):
        try:
            self.kod.pop().deleteLater()
        except:
            pass
    def play_all(self):
        if self.stop_flag == 0:
            try:
                track = np.zeros(len(self.kod[0].sig_int))
            except:
                return None
            count = 1
            for i in range(0, len(self.kod)):
                if not isinstance(self.kod[i], Test) or self.kod[i].muted == 1:
                    continue
                new_track = deepcopy(self.kod[i].sig_int)
                if len(new_track) < len(track):
                    new_track = np.pad(new_track,(0,len(track)-len(new_track)),mode='constant', constant_values=0)
                elif len(new_track) > len(track):
                    track = np.pad(track,(0,len(new_track)-len(track)),mode='constant', constant_values=0)
                count += 1
                track = np.add(track, new_track*self.kod[i].tslid.multiplier)
            track = np.divide(track, count)
            track /= 32768.0
            self.playbutton.setIcon(self.stop_btn)
            self.playbutton.setToolTip("Stop")
            self.stop_flag=1
            sd.play(track, self.kod[0].fs)

        else:
            self.playbutton.setIcon(self.play_btn)
            self.playbutton.setToolTip("Play")
            sd.play(self.silence,44100)
            self.stop_flag=0

    def export_track(self):
        text, ok = QtGui.QInputDialog.getText(self, '', 'Export as:')
        if ok:
            self.export_name = "{}.wav".format(str(text))
        else:
            return None
        count = 1
        track = self.kod[0].sig_int * self.kod[0].tslid.multiplier
        for i in range(1, len(self.kod)):
            if not isinstance(self.kod[i], Test) or self.kod[i].muted == 1:
                continue
            new_track = deepcopy(self.kod[i].sig_int)
            if len(new_track) < len(track):
                new_track = np.pad(new_track, (0, len(track) - len(new_track)), mode='constant', constant_values=0)
            elif len(new_track) > len(track):
                track = np.pad(track, (0, len(new_track) - len(track)), mode='constant', constant_values=0)
            count += 1
            track = np.add(track, new_track * self.kod[i].tslid.multiplier)
        track = np.int16(np.divide(track, count))
        write(self.export_name, 44100, track)




class Test(QtGui.QWidget):
    time=0
    index=0
    track=()
    track_name = ""
    signal=[]
    sig_int=()
    fs=0
    muted=0

    def __init__(self,ln, parent=None):
        super(Test, self).__init__(parent)
        self.index=ln
        self.track=()
        self.track_name = ""
        self.signal=[]
        self.sig_int=()
        self.fs=0
        self.play_thread=0
        self.stop_flag=0
        self.sig_int=()
        self.time=0
        self.slidv=0
        self.muted=0

        self.play_icon = QtGui.QIcon("play2.png")
        self.stop_icon = QtGui.QIcon("stop2.png")
        self.mute_icon = QtGui.QIcon("mute.png")
        self.unmute_icon = QtGui.QIcon("unmute.png")
        self.paste_icon = QtGui.QIcon("paste.png")
        self.delete_icon = QtGui.QIcon("delete.jpg")
        self.copy_icon = QtGui.QIcon("copy2.png")
        self.cut_icon = QtGui.QIcon("cut2.jpeg")


        self.figure= Figure(tight_layout=True)
        self.canvas = FigureCanvas(self.figure)

        self.rm=QtGui.QPushButton()
        self.rm.clicked.connect(self.rmv)
        self.rm.setFixedSize(50,30)
        self.rm.setIcon(self.delete_icon)
        self.rm.setStyleSheet("background-color: white")
        self.rm.setToolTip("Delete")

        self.imp = QtGui.QPushButton("import")
        self.imp.clicked.connect(self.imprt)
        self.imp.setFixedSize(105,30)
        self.imp.setStyleSheet("background-color: white")
        self.imp.setToolTip("Import")

        self.play = QtGui.QPushButton()
        self.play.clicked.connect(self.play_sound)
        self.play.setFixedSize(50, 30)
        self.play.setIcon(self.play_icon)
        self.play.setStyleSheet("background-color: white")
        self.play.setToolTip("Play")

        self.mute = QtGui.QPushButton()
        self.mute.clicked.connect(self.mute_track)
        self.mute.setFixedSize(50, 30)
        self.mute.setIcon(self.mute_icon)
        self.mute.setStyleSheet("background-color: white")
        self.mute.setToolTip("Mute")

        self.copy = QtGui.QPushButton()
        self.copy.clicked.connect(self.copy_track)
        self.copy.setFixedSize(50, 30)
        self.copy.setIcon(self.copy_icon)
        self.copy.setStyleSheet("background-color: white")
        self.copy.setToolTip("Copy")

        self.cut = QtGui.QPushButton()
        self.cut.clicked.connect(self.cut_track)
        self.cut.setFixedSize(50, 30)
        self.cut.setIcon(self.cut_icon)
        self.cut.setStyleSheet("background-color: white")
        self.cut.setToolTip("Cut")

        self.paste = QtGui.QPushButton()
        self.paste.clicked.connect(self.paste_track)
        self.paste.setFixedSize(50, 30)
        self.paste.setIcon(self.paste_icon)
        self.paste.setStyleSheet("background-color: white")
        self.paste.setToolTip("Paste")

        self.vslider = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.vslider.setTickPosition(QtGui.QSlider.TicksBelow)
        self.vslider.setTickInterval(5)
        self.vslider.sliderReleased.connect(self.slidval)

        self.name_label = QtGui.QLabel()




        self.tslid = Vslider()
        self.poz = PozSlider()


        layout=QtGui.QGridLayout()
        layout.addWidget(self.imp, 1 ,1 ,1 ,2 )
        layout.addWidget(self.rm, 2, 1, 1, 1)
        layout.addWidget(self.play, 2, 2, 1, 1)
        layout.addWidget(self.mute, 3, 1, 1, 1)
        layout.addWidget(self.copy, 3, 2, 1, 1)
        layout.addWidget(self.cut, 4, 1, 1, 1)
        layout.addWidget(self.paste, 4, 2, 1, 1)

        layout.addWidget(self.name_label,6,1,1,3)
        layout.addWidget(self.poz,6,4,1,100)
        layout.addWidget(self.tslid,1,3,4,1)


        layout.addWidget(self.canvas,1,4,4,100)

        self.setLayout(layout)

    def slidval(self):
        self.slidv = [self.poz.start,self.poz.end]
        print(self.slidv)

    def rmv(self):
        try:
            Main.kod[self.index].deleteLater()
            Main.kod[self.index] = 0
        except:
            pass


    def imprt(self):
        try:
            name = QtGui.QFileDialog.getOpenFileName(self,'Open File',"Audio Files (*.mp3 *.wav *.ogg)")
            self.track = wave.open(name,'rb')
            self.signal=self.track.readframes(-1)
            self.sig_int = np.fromstring(self.signal, 'Int16')
            self.fs = self.track.getframerate()
            self.track_name = name
            self.name_label.setText(self.track_name.split("/")[-1])
            self.plot()
        except:
            pass


    def inline_play(self):
        self.play_thread = threading.Thread(target=self.play_sound2, args=[])
        self.play_thread.start()

    def play_sound(self):
        if self.stop_flag == 0:
            start = int((len(self.sig_int) * self.poz.start) / 100)
            end = int((len(self.sig_int) * self.poz.end) / 100)
            track = deepcopy(self.sig_int[start:end+1])
            self.play.setIcon(self.stop_icon)
            self.play.setToolTip("Stop")
            self.stop_flag=1
            sd.play(track/32768.0*self.tslid.multiplier, self.fs)
        else:
            self.stop_flag=0
            self.play.setIcon(self.play_icon)
            self.play.setToolTip("Play")
            sd.play(np.zeros(44100),44100)
    '''
    def play_sound2(self):
        CHUNK = 1024

        wf = wave.open(self.track_name, 'rb')
        p = pyaudio.PyAudio()
        stream = p.open(format=p.get_format_from_width(wf.getsampwidth()),
                    channels=wf.getnchannels(),
                    rate=wf.getframerate(),
                    output=True)
        data = wf.readframes(CHUNK)
        while len(data) > 0:
            stream.write(data)
            data = wf.readframes(CHUNK)
        stream.stop_stream()
        stream.close()
        p.terminate()
        return True
        '''


    def plot(self):
        ''' plot some random stuff '''
        # random data

        signal=self.sig_int/32768.0
        tcounter=len(signal)
        fs = self.fs
        signal=[signal[x] for x in range(0,len(signal),1000)]

        self.time = np.linspace(0, tcounter/fs, num=len(signal))
        t=[x for x in range(len(signal))]



        # create an axis
        fig, ax = plt.subplots()
        ax = self.figure.add_subplot(111)
        self.figure.tight_layout()
        a={'pad':0,'h_pad':0,'w_pad':0,'rect':(0,0,0,0)}
        self.figure.set_tight_layout(tight=a)
        # discards the old graph
        ax.clear()
        ax.set_xticklabels([])
        ax.set_yticklabels([])
        ax.axis("off")
        self.figure.tight_layout()
        # plot data
        ax.plot(signal)
        self.figure.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=None)
        # refresh canvas
        self.canvas.draw()


    def mute_track(self):
        if self.muted == 0:
            self.muted=1
            self.mute.setIcon(self.unmute_icon)
            self.mute.setToolTip("Unmute")
        else:
            self.muted=0
            self.mute.setIcon(self.mute_icon)
            self.mute.setToolTip("Mute")

    def copy_track(self):
        start = int((len(self.sig_int) * self.poz.start) / 100)
        end = int((len(self.sig_int) * self.poz.end) / 100)
        Main.pastable = self.sig_int[start:end+1]

    def cut_track(self):
        start = int((len(self.sig_int) * self.poz.start) / 100)
        end = int((len(self.sig_int) * self.poz.end) / 100)
        Main.pastable = deepcopy(self.sig_int[start:end + 1])
        for i in range(start,end+1):
            self.sig_int[i]=0
        self.plot()
    def paste_track(self):
        start = int((len(self.sig_int) * self.poz.start) / 100)
        for i in range(len(Main.pastable)):
            try:
                self.sig_int[start+i] = Main.pastable[i]
            except IndexError:
                self.sig_int.append(Main.pastable[i])
            except:
                break
        self.plot()


class Vslider(QtGui.QWidget):
    multiplier=1
    def __init__(self ,parent=None):
        super(Vslider, self).__init__(parent)

        self.vslider = QtGui.QSlider(QtCore.Qt.Vertical)
        self.vslider.setMinimum(-10)
        self.vslider.setMaximum(10)
        self.vslider.setTickPosition(QtGui.QSlider.TicksLeft)
        self.vslider.setTickInterval(2)
        self.vslider.sliderReleased.connect(self.setMulti)
        self.vslider.setToolTip("Volume +/-")

        self.plus = QtGui.QLabel("+")
        self.minus = QtGui.QLabel("-")

        layout = QtGui.QGridLayout()
        layout.addWidget(self.vslider,0,0,4,1)
        layout.addWidget(self.plus,0,1,1,1)
        layout.addWidget(self.minus,3,1,1,1)

        self.setLayout(layout)

    def setMulti(self):
        val = self.vslider.value()
        self.multiplier = math.pow(1.122,val)

class PozSlider(QtGui.QWidget):
    start = 0
    end = 99
    def __init__(self, parent=None):
        super(PozSlider, self).__init__(parent)
        self.start=0
        self.end=100

        self.start_slider = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.start_slider.setTickPosition(QtGui.QSlider.TicksAbove)
        self.start_slider.sliderReleased.connect(self.set_start)
        self.start_slider.setToolTip("Set starting location")

        self.end_slider = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.end_slider.setTickPosition(QtGui.QSlider.TicksBelow)
        self.end_slider.sliderReleased.connect(self.set_end)
        self.end_slider.setSliderPosition(99)
        self.end_slider.setToolTip("Set end location")

        layout = QtGui.QVBoxLayout()
        layout.addWidget(self.start_slider)
        layout.addWidget(self.end_slider)
        self.setLayout(layout)

    def set_start(self):
        self.start = self.start_slider.value()
        if self.start > self.end:
            self.start = self.end
            self.start_slider.setSliderPosition(self.end)
    def set_end(self):
        self.end=self.end_slider.value()
        if self.end < self.start:
            self.end = self.start
            self.end_slider.setSliderPosition(self.start)

app = QtGui.QApplication(sys.argv)
myWidget = Main()
myWidget.show()
app.exec_()
#kill me pls i want to die