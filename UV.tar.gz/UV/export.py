from PIL import Image
import sys


if (len(sys.argv)) != 3:
    print("Command needs the name of the original image and the name you want for the new image")
    exit()



im_name = sys.argv[1]
im_new = sys.argv[2]

im_newname = im_new
try:
    im_newformat = im_new.split(".")[1]
except:
    im_newformat="png"


try:
    im = Image.open(im_name)
except IOError:
    print("File is not an image")
    exit()
try:
    im.save(im_newname, im_newformat)
except:
    print("Image cannot be saved as a ."+im_newformat+" file")

exit()
