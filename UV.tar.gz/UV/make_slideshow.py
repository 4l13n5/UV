import os
import sys
from PIL import Image

new_dir = input("Enter the name of the new slideshow:")

mkdir = "mkdir "+new_dir

os.system(mkdir)

print("\nEnter image names to add them to folder, enter 'stop' to finish")

while True:
    im = input()
    if im == "stop":
        break
    try:
        img = Image.open(im)
        cm = "cp "+im+" ./"+new_dir
        os.system(cm)
    except:
        print("Image not found")

exit()