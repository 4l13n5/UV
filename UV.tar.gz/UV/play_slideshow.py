import sys
import os

if len(sys.argv) != 2 or not os.path.exists("./"+sys.argv[1]):
    print("Command needs the slideshow name as argument")
    exit()

cm = "eog --slide-show "+"./"+sys.argv[1]
os.system(cm)

