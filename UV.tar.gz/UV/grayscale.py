from PIL import Image
import sys

try:
    im_name = sys.argv[1]
    im = Image.open(im_name)
except:
    print("Image not found, command needs image name as argument")
    exit()

im.convert('L').save(im_name)
exit()
