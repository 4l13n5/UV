from PIL import Image
import sys
from openImage import img

im = img

img.rotate(180)