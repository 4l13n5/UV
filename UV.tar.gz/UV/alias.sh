#!/bin/bash

alias openImage="python3 openImage.py"
alias export="python3 export.py"
alias rotate="python3 rotate.py"
alias resize="python3 resize.py"
alias crop="python3 crop.py"
alias new_slideshow="python3 make_slideshow.py"
alias play="python3 play_slideshow.py"
alias grayscale="python3 grayscale.py"
alias index="python3 Indexed.py"
