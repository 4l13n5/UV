from PIL import Image
import sys

if len(sys.argv) != 3:
    print("Command needs the image name and the number of desired colours")
    exit()

try:
    im_name = sys.argv[1]
    im = Image.open(im_name)
except:
    print("Image not found")
    exit()

try:
    color_count = int(sys.argv[2])
except:
    print("Second argument must be an integer")
    exit()


im.convert('P', palette=Image.ADAPTIVE, colors=color_count).convert('RGB').save(im_name)
exit()
