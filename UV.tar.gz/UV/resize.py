import sys
from PIL import Image

if len(sys.argv) != 4:
    print("Command needs image name, new width and new height")
    exit()

try:
    im = Image.open(sys.argv[1])
except:
    print("File not found or not an image")
    exit()

im_name = sys.argv[1]
try:
    im_width = int(sys.argv[2])
    im_height = int(sys.argv[3])
except:
    print("Second and third arguments must be integers")
    exit()


im.resize((im_width,im_height)).save(im_name)

exit()