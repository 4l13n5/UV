from PIL import Image
import sys

try:
    im = Image.open(sys.argv[1])
    width,height=im.size
    im_name = sys.argv[1]
except:
    print("File not found or not an image")
    exit()

ll = input("Enter X[0-{}] and Y[0-{}] coordinate of upper left corner: ".format(width,height))
try:
    xl = int(ll.split(" ")[0])
    yl = int(ll.split(" ")[1])
except:
    print("Please enter two integer numbers")
    exit()

ur = input("Enter X[0-{}] and Y[0-{}] coordinate of lower right corner: ".format(width,height))
try:
    xu = int(ur.split(" ")[0])
    yu = int(ur.split(" ")[1])
except:
    print("Please enter two integer numbers")
    exit

im.crop((xl, yl, xu, yu)).save(im_name)

exit()