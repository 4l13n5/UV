import sys
from PIL import Image

if len(sys.argv) != 3:
    print("Command needs the name of image you wish to rotate and the angle of rotation")

try:
    im = Image.open(sys.argv[1])
except:
    print("File not found or not an image")
    exit()

im_name = sys.argv[1]
try:
    im_deg = int(sys.argv[2])
except:
    print("Second argument must be and integer")

im.rotate(im_deg,expand=True).save(im_name)

exit()