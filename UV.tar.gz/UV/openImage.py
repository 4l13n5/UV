from PIL import Image
import sys
import os

try:
    img = Image.open(sys.argv[1])
    im_name = sys.argv[1]
except:
    print("File not found or not an image")
    exit()

cm = "eog "+im_name+" &"
os.system(cm)
